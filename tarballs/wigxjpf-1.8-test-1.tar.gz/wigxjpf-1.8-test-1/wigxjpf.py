#
# Copyright 2015 Christian Forssen
#
#  This file is part of WIGXJPF.
#
#  WIGXJPF is free software: you can redistribute it and/or modify it
#  under the terms of the GNU Lesser General Public License as
#  published by the Free Software Foundation, either version 3 of the
#  License, or (at your option) any later version.
#
#  WIGXJPF is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with WIGXJPF.  If not, see
#  <http://www.gnu.org/licenses/>.
#

"""
Filename: pywigxjpf.py
Python interface to the wigxjpf (dynamic) library with the use of cffi.
Defines seven functions:

    (1) wig_table_init(max_two_j,wigner_type)
    (2) wig_table_free()
    (3) wig_temp_init(max_two_j)
    (4) wig_temp_free()
    (5) wig3jj(jj1,jj2,jj3,
               mm1,mm2,mm3)
    (6) wig6jj(jj1,jj2,jj3,
               jj4,jj5,jj6)
    (7) wig9jj(jj1,jj2,jj3,
               jj4,jj5,jj6,
               jj7,jj8,jj9)
"""

__version__ = '1.8.111'


from wigxjpf.wigxjpf_ffi import ffi, lib
from textwrap import dedent

wig_table_init = lib.wig_table_init
wig_table_init.__doc__ = dedent('''
    Initialize the binomial tables

    Parameters
    ----------
    max_two_j: int
        The largest two_j that will be passed to wigxjpf
    wigner_type: one of {3, 6, 9} as an int
        The largest class of symbols to be used.  Undefined behavoir if not 3, 6, or 9

''')

wig_table_free = lib.wig_table_free
wig_table_free.__doc__ = dedent('''Free the binomial tables''')

wig_temp_init  = lib.wig_temp_init
wig_temp_init.__doc__ = dedent('''
    Allocate the cache arrays for wigxjpf

    Parameters
    ----------
    max_two_j: int
        The largest two_j that will be passed to wigxjpf

''')

wig_temp_free  = lib.wig_temp_free
wig_temp_free.__doc__ = dedent('''Free the internal caches arrays''')

three_j = lib.wig3jj
three_j.__doc__ = dedent('''
    Compute a Wigner 3j symbol

    Parameters
    ----------
    two_j1, two_j2, two_j3: int
        twice the angular momenta
    two_m1, two_m2, two_m3: int 
        twice the angular momenta projection

    Returns
    -------
    The value of the Wigner 3j symbol 
''')



six_j = lib.wig6jj
six_j.__doc__ = dedent('''
    Compute a Wigner 6j symbol

    Parameters
    ----------
    two_j1, two_j2, two_j3, two_j4, two_j5, two_j6: int
        twice the angular momenta

    Returns
    -------
    The value of the Wigner 6j symbol 
''')

nine_j = lib.wig9jj
six_j.__doc__ = dedent('''
    Compute a Wigner 9j symbol

    Parameters
    ----------
    two_j1, two_j2, two_j3, two_j4, two_j5, two_j6, two_j7, two_j8, two_j9: int
        twice the angular momenta

    Returns
    -------
    The value of the Wigner 9j symbol 
''')