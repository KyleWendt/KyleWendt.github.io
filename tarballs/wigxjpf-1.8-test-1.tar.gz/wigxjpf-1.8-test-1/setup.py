#!/usr/bin/env python

from setuptools import setup, find_packages
# print(find_packages())

setup(name='pywigxjpf',
      version='1.8.111',
      description='Wrapper for the wigxjpf Wigner Symbols library by C. Forssen and H. T. Johansson',
      license = "GPLv3",
      author='H. T. Johansson, ',
      url='http://fy.chalmers.se/subatom/wigxjpf',
      packages=['wigxjpf'],
      # package_data={'wigxjpf': ['../lib/libwigxjpf_shared.*']},
      setup_requires=["cffi>=1.0.0"],
      cffi_modules=["wigxjpf/build_wigxjpf.py:ffibuilder"],
      install_requires=["cffi>=1.0.0"],
     )
